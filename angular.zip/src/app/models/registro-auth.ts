export class user{
    id?: number;
    nombre?: string;
    telefono?: string;
    email?: any;
    password?: any;
}