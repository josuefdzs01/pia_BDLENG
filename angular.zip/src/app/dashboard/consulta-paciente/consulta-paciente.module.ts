import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConsultaPacienteComponent } from './consulta-paciente.component';



@NgModule({
  declarations: [ConsultaPacienteComponent],
  imports: [
    CommonModule
  ]
})
export class ConsultaPacienteModule { }
