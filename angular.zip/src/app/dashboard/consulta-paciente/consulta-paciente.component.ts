import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consulta-paciente',
  templateUrl: './consulta-paciente.component.html'
})
export class ConsultaPacienteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
