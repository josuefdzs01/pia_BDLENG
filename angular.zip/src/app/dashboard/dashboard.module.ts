import { DashboardComponent } from './dashboard.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { RegistroPacienteComponent } from './registro-paciente/registro-paciente.component';
import { ConsultaPacienteComponent } from './consulta-paciente/consulta-paciente.component';
import { RegistroPacienteModule } from './registro-paciente/registro-paciente.module';
import { ConsultaPacienteModule } from './consulta-paciente/consulta-paciente.module';
import { ForgotPasswordComponent } from '../forgot-password/forgot-password.component';



@NgModule({
  declarations: [DashboardComponent],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    RegistroPacienteModule,
    ConsultaPacienteModule
  ]
})
export class DashboardModule { }
