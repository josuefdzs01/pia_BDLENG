import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registro-paciente',
  templateUrl: './registro-paciente.component.html'
})
export class RegistroPacienteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
