import { RegistroPacienteComponent } from './registro-paciente.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [RegistroPacienteComponent],
  imports: [
    CommonModule
  ]
})
export class RegistroPacienteModule { }
